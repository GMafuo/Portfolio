# 24_Fernandes.md
Porjet d'étude Iut S2 tkt
groupe numéro : 24

* étudiant référent : Adrien Fernandes
* étudiant 2 : Giuliana Godail_Fabrizio
* étudiant 3 : Girard Mathéo

URL du projet github : https://github.com/Afernan9/Sae-S2-3.4.5

URL du site pythonanywhere : http://khezku.pythonanywhere.com/
