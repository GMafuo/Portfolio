#! /usr/bin/python
# -*- coding:utf-8 -*-
from flask import Blueprint, flash, url_for
from flask import request, render_template, redirect

from connexion_db import get_db

admin_adresse = Blueprint('admin_adresse', __name__, template_folder='templates')

@admin_adresse.route('/admin/adress/show')
def show_adress():
    mycursor = get_db().cursor()

    sql = '''SELECT * FROM pointRelais;'''
    mycursor.execute(sql)
    adresse = mycursor.fetchall()

    return render_template('admin/adresse/show_adress.html', adresse=adresse)

@admin_adresse.route('/admin/adress/add', methods=['GET'])
def add_adress():
    return render_template('admin/adresse/add_adress.html')


@admin_adresse.route('/admin/adress/add', methods=['POST'])
def valid_add_address():
    mycursor = get_db().cursor()
    ville = request.form.get('ville')
    adress = request.form.get('adress')
    # __________________________________________________________________________________________________________________
    tuple_insert = (ville, adress)
    sql = '''insert into pointRelais (ville, adresse)
             values(%s,%s);'''
    mycursor.execute(sql, tuple_insert)

    get_db().commit()
    # __________________________________________________________________________________________________________________
    print('meuble ajouté , adresse: ', adress, ' - ville', ville)
    message = 'meuble ajouté , ville:' + ville + ' - adresse: ' + adress
    flash(message)
    return redirect(url_for('admin_adresse.show_adress'))


@admin_adresse.route('/admin/adresse/del/<int:idPts>', methods=['GET'])
def delete_address(idPts):
    mycursor = get_db().cursor()

    sql = '''select * from commande where id_pointRelais = %s;'''
    mycursor.execute(sql, idPts)
    result = mycursor.fetchone()
    print(result)

    if result == None:
        sql = '''delete from pointRelais where id_pointRelais = %s;'''
        mycursor.execute(sql, idPts)
        get_db().commit()
    else :
        flash('impossible de supprimer car utilisée pour une livraison')
    return redirect(url_for('admin_adresse.show_adress'))
